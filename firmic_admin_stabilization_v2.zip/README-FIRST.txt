FIRMIC ADMIN STABILIZATION V1

Replace each file in your Firmic repository using the same relative path.

Key fixes:
- Company dependency-tree delete backend retained.
- Company Activation Fee naming standardized at USD 49.
- Legacy "Hookup Fee" ledger rows migrate in place; no duplicate fee.
- Billing API/UI uses Activation Fee terminology.
- Settings exposes activation_fee_usd with legacy fallback.
- Analytics uses Company Activation Fee wording.
- Command Center "Open" company links now open Company Inspector.
- Command Center quick actions cover Billing, Companies, Offices,
  Compliance, Support, Reports, AI Workforce, Users, and Settings.
- Office-company links open Company Inspector.
- Compliance Platform display uses live state and shows Active.
- Approval immediately reconciles API result and then refreshes queue.
- Dedicated Admin Login is separate from Tenant Login.
- Hard-coded admin credentials removed from frontend source.
- Existing admin sessions redirect straight into /admin.

Validation:
- Backend/routes/admin.py passed Python compile.

After replacing:
  cd ~/Desktop/Firmic
  python -m py_compile Backend/routes/admin.py
  cd frontend
  npm run build

Only commit/push after the build passes.
