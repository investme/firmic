import type { AppProps } from "next/app";
import { useRouter } from "next/router";

import "../styles/globals.css";

import { WorkspaceProvider } from "../src/context/WorkspaceProvider";
import { OSProvider } from "../src/os/OSProvider";
import { FirmicActionSystem } from "../src/os/actions";
import {
  ActionEventBridge,
  FirmicEventSystem,
} from "../src/os/events";
import { FirmicNotificationSystem } from "../src/os/notifications";
import { SidebarProvider } from "../src/os/sidebar";

export default function App({
  Component,
  pageProps,
}: AppProps) {
  const router = useRouter();

  const isAdminLogin = router.pathname === "/admin-login";

  const isAdminRoute =
    router.pathname === "/admin" ||
    router.pathname.startsWith("/admin-");

  // Admin login is intentionally isolated from both tenant and admin
  // application providers.
  if (isAdminLogin) {
    return <Component {...pageProps} />;
  }

  // Admin pages still require SidebarProvider because AdminSidebar renders
  // SidebarEngine, but they must not start tenant workspace, notification,
  // event, or action systems.
  if (isAdminRoute) {
    return (
      <SidebarProvider>
        <Component {...pageProps} />
      </SidebarProvider>
    );
  }

  // Tenant application runtime.
  return (
    <WorkspaceProvider>
      <OSProvider>
        <FirmicEventSystem>
          <FirmicNotificationSystem>
            <SidebarProvider>
              <FirmicActionSystem>
                <ActionEventBridge />
                <Component {...pageProps} />
              </FirmicActionSystem>
            </SidebarProvider>
          </FirmicNotificationSystem>
        </FirmicEventSystem>
      </OSProvider>
    </WorkspaceProvider>
  );
}
