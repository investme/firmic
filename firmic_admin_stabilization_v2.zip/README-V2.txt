FIRMIC ADMIN STABILIZATION V2

This patch corrects the issues found in live testing.

1. COMPANY ACTIVATION FEE
   - Canonical price is now USD 79.
   - Existing $49 activation/hookup ledger entries are reconciled in place.
   - amount, tax_amount, total_amount, label, action and metadata are updated.
   - No duplicate activation fee is created.

2. COMPLIANCE PLATFORM STATE
   - Company.status="active" no longer falsely makes Hermes show Platform: Active.
   - Platform is Active only when platform_unlocked=true or Launch Engine status=active.
   - A company missing even one mandatory document will therefore remain Locked.

3. MISSING DOCUMENT WORKFLOW
   - Hermes Inspector now explains the exact path:
       Request missing doc
       -> tenant /documents
       -> tenant submits requested item
       -> Admin Verify
       -> Approve & Activate Company.
   - Request button shows the exact missing-document count.

4. ADMIN LOGIN
   - No code change is required in V2.
   - If an admin JWT already exists, /admin-login correctly redirects to /admin.
   - To test the dedicated Admin Access page, press Logout or use Incognito.
   - Production target remains admin.firmic.io.

INSTALL:
Copy the files in this ZIP over the same relative paths.

VALIDATE:
cd ~/Desktop/Firmic
python -m py_compile Backend/routes/admin.py

cd frontend
npm run build

Then start locally and test Billing + Compliance.
