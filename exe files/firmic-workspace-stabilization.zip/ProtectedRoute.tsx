import { ReactNode, useEffect, useState } from "react";
import { useRouter } from "next/router";
import { useRequireAuth } from "../hooks/useRequireAuth";
import { getCompanies, getCompany } from "../services/companyApi";
import {
  clearActiveWorkspace,
  getActiveWorkspaceId,
  saveActiveWorkspace,
} from "../src/utils/workspaceContext";

type Props = { children: ReactNode };

type Company = {
  id: string | number;
  name?: string;
  status?: string;
};

const WORKSPACE_OPTIONAL_PATHS = new Set([
  "/companies",
  "/create-company",
]);

export default function ProtectedRoute({ children }: Props) {
  const router = useRouter();
  const { checkingAuth } = useRequireAuth();
  const [checkingWorkspace, setCheckingWorkspace] = useState(true);
  const [workspaceError, setWorkspaceError] = useState("");

  useEffect(() => {
    if (checkingAuth || !router.isReady) return;

    let cancelled = false;

    async function hydrateWorkspace() {
      try {
        setCheckingWorkspace(true);
        setWorkspaceError("");

        const response = await getCompanies();
        const companies: Company[] = Array.isArray(response)
          ? response.filter(
              (company) =>
                String(company.status || "").toLowerCase() !== "terminated"
            )
          : [];

        if (cancelled) return;

        if (companies.length === 0) {
          clearActiveWorkspace();
          if (router.pathname !== "/create-company") {
            await router.replace("/create-company");
          }
          return;
        }

        const selectedId = getActiveWorkspaceId();
        let selectedCompany = selectedId
          ? companies.find(
              (company) => String(company.id) === String(selectedId)
            )
          : undefined;

        if (!selectedCompany && companies.length === 1) {
          selectedCompany = companies[0];
        }

        if (!selectedCompany) {
          clearActiveWorkspace();
          if (!WORKSPACE_OPTIONAL_PATHS.has(router.pathname)) {
            await router.replace("/companies");
          }
          return;
        }

        const freshCompany = await getCompany(String(selectedCompany.id));
        if (cancelled) return;

        saveActiveWorkspace(freshCompany);
      } catch (error: any) {
        console.error("Workspace hydration failed:", error);
        if (!cancelled) {
          setWorkspaceError(
            error?.message || "Failed to load the active company."
          );
        }
      } finally {
        if (!cancelled) setCheckingWorkspace(false);
      }
    }

    hydrateWorkspace();

    return () => {
      cancelled = true;
    };
  }, [checkingAuth, router.isReady, router.pathname]);

  if (checkingAuth || checkingWorkspace) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-center">
          <div className="h-12 w-12 rounded-full border-4 border-violet-600 border-t-transparent animate-spin mx-auto" />
          <p className="mt-6 text-slate-500 font-medium">
            Loading your workspace...
          </p>
        </div>
      </div>
    );
  }

  if (workspaceError) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 p-6">
        <div className="max-w-lg w-full bg-white border border-red-200 rounded-3xl p-6 shadow-sm">
          <h1 className="text-xl font-bold text-red-700">
            Workspace could not load
          </h1>
          <p className="text-slate-600 mt-3">{workspaceError}</p>
          <button
            type="button"
            onClick={() => window.location.reload()}
            className="mt-5 w-full bg-violet-600 text-white py-3 rounded-xl font-bold"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}
