export type FirmicHeadquarters = {
  office_id?: string | number | null;
  office_code: string;
  office_name?: string;
  location: string;
  phone?: string;
  mailbox?: boolean;
  status?: string;
  monthly_price_usd?: number;
};

export type FirmicWorkspace = {
  id: string;
  name: string;
  industry?: string;
  jurisdiction?: string;
  plan?: string;
  headquarters?: FirmicHeadquarters | null;
  status?: string;
};

const WORKSPACE_KEY = "firmic_workspace";
const WORKSPACE_ID_KEY = "firmic_workspace_id";
const WORKSPACE_CHANGED_EVENT = "firmic-workspace-changed";

function isBrowser(): boolean {
  return typeof window !== "undefined";
}

function normalizeWorkspace(value: unknown): FirmicWorkspace | null {
  if (!value || typeof value !== "object") return null;

  const candidate = value as Record<string, unknown>;
  const id = typeof candidate.id === "string" || typeof candidate.id === "number"
    ? String(candidate.id)
    : "";
  const name = typeof candidate.name === "string" ? candidate.name.trim() : "";

  if (!id || !name) return null;

  return {
    id,
    name,
    industry: typeof candidate.industry === "string" ? candidate.industry : undefined,
    jurisdiction: typeof candidate.jurisdiction === "string" ? candidate.jurisdiction : undefined,
    plan: typeof candidate.plan === "string" ? candidate.plan : undefined,
    headquarters:
      candidate.headquarters && typeof candidate.headquarters === "object"
        ? (candidate.headquarters as FirmicHeadquarters)
        : null,
    status: typeof candidate.status === "string" ? candidate.status : undefined,
  };
}

function dispatchWorkspaceChanged(): void {
  if (!isBrowser()) return;
  window.dispatchEvent(new CustomEvent(WORKSPACE_CHANGED_EVENT));
}

function removeLegacyWorkspaceKeys(): void {
  if (!isBrowser()) return;
  [
    "firmic_company",
    "company_id",
    "company_name",
    "company_jurisdiction",
    "company_plan",
    "company_office_code",
    "company_office_location",
    "selected_office",
    "rented_office",
  ].forEach((key) => localStorage.removeItem(key));
}

export function getActiveWorkspace(): FirmicWorkspace | null {
  if (!isBrowser()) return null;

  try {
    const stored = localStorage.getItem(WORKSPACE_KEY);
    if (!stored) return null;

    const normalized = normalizeWorkspace(JSON.parse(stored));
    if (!normalized) {
      localStorage.removeItem(WORKSPACE_KEY);
      return null;
    }

    return normalized;
  } catch (error) {
    console.error("Failed to read active workspace:", error);
    localStorage.removeItem(WORKSPACE_KEY);
    return null;
  }
}

export function getActiveWorkspaceId(): string | null {
  if (!isBrowser()) return null;

  const storedId = localStorage.getItem(WORKSPACE_ID_KEY);
  if (storedId) return storedId;

  return getActiveWorkspace()?.id || null;
}

export function saveActiveWorkspace(workspace: FirmicWorkspace): FirmicWorkspace | null {
  if (!isBrowser()) return null;

  const normalized = normalizeWorkspace(workspace);
  if (!normalized) {
    console.error("Invalid workspace:", workspace);
    return null;
  }

  try {
    localStorage.setItem(WORKSPACE_ID_KEY, normalized.id);
    localStorage.setItem(WORKSPACE_KEY, JSON.stringify(normalized));
    removeLegacyWorkspaceKeys();
    dispatchWorkspaceChanged();
    return normalized;
  } catch (error) {
    console.error("Failed to save active workspace:", error);
    return null;
  }
}

export function updateActiveWorkspace(
  updates: Partial<FirmicWorkspace>
): FirmicWorkspace | null {
  const workspace = getActiveWorkspace();
  if (!workspace) return null;

  return saveActiveWorkspace({
    ...workspace,
    ...updates,
    id: workspace.id,
    name:
      typeof updates.name === "string" && updates.name.trim()
        ? updates.name.trim()
        : workspace.name,
  });
}

export function setActiveHeadquarters(
  headquarters: FirmicHeadquarters
): FirmicWorkspace | null {
  return updateActiveWorkspace({ headquarters });
}

export function getActiveHeadquarters(): FirmicHeadquarters | null {
  return getActiveWorkspace()?.headquarters || null;
}

export function clearActiveWorkspace(): void {
  if (!isBrowser()) return;

  localStorage.removeItem(WORKSPACE_KEY);
  localStorage.removeItem(WORKSPACE_ID_KEY);
  removeLegacyWorkspaceKeys();
  dispatchWorkspaceChanged();
}

export function getWorkspaceChangedEventName(): string {
  return WORKSPACE_CHANGED_EVENT;
}
