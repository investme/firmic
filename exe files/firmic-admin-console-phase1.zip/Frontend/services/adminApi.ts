import { API_URL } from "./config";

function headers() {
  const token =
    typeof window !== "undefined"
      ? localStorage.getItem("firmic_token")
      : null;

  if (!token) throw new Error("Admin authentication required.");

  return {
    "Content-Type": "application/json",
    Authorization: `Bearer ${token}`,
  };
}

async function request(path: string, options: RequestInit = {}) {
  const response = await fetch(`${API_URL}${path}`, {
    ...options,
    cache: "no-store",
    headers: {
      ...headers(),
      ...(options.headers || {}),
    },
  });

  const text = await response.text();

  if (!response.ok) {
    let message = text || "Admin request failed";
    try {
      message = JSON.parse(text)?.detail || message;
    } catch {}
    throw new Error(message);
  }

  return text ? JSON.parse(text) : null;
}

export const getAdminDashboard = () => request("/api/admin/dashboard");
export const getAdminCompanies = () => request("/api/admin/companies");
export const getAdminOffices = () => request("/api/admin/offices");
export const getAdminCompany = (companyId: string) =>
  request(`/api/admin/companies/${companyId}`);

export const terminateAdminCompany = (companyId: string) =>
  request(`/api/admin/companies/${companyId}/terminate`, { method: "POST" });

export const restoreAdminCompany = (companyId: string) =>
  request(`/api/admin/companies/${companyId}/restore`, { method: "POST" });

export const deleteAdminCompany = (companyId: string) =>
  request(`/api/admin/companies/${companyId}`, { method: "DELETE" });

export const getAdminModuleSummary = (moduleName: string) =>
  request(`/api/admin/summary/${moduleName}`);

export const getAdminBilling = () => request("/api/admin/billing");
export const getAdminCompanyBilling = (companyId: string) =>
  request(`/api/admin/billing/company/${companyId}`);

export const markAdminCompanyBilled = (companyId: string) =>
  request(`/api/admin/billing/company/${companyId}/mark-billed`, {
    method: "POST",
  });

export const markAdminCompanyPaid = (companyId: string) =>
  request(`/api/admin/billing/company/${companyId}/mark-paid`, {
    method: "POST",
  });

export const backfillAdminHookupFees = () =>
  request("/api/admin/billing/backfill-hookup-fees", { method: "POST" });

export const getAdminAIWorkforce = () =>
  request("/api/admin/ai-workforce");

export const getAdminUsers = () =>
  request("/api/admin/users");

export const getAdminSettings = () =>
  request("/api/admin/settings");

export const getAdminAnalytics = () =>
  request("/api/admin/analytics");

export const getAdminSupport = () =>
  request("/api/admin/support");
