import { useEffect,useState } from "react";
import AdminSidebar from "../components/AdminSidebar";
import AdminProtectedRoute from "../components/AdminProtectedRoute";
import { getAdminAnalytics } from "../services/adminApi";

export default function AdminAnalytics(){
 const [data,setData]=useState<any>(null);const [error,setError]=useState("");const [loading,setLoading]=useState(true);
 useEffect(()=>{load()},[]);
 async function load(){try{setLoading(true);setError("");setData(await getAdminAnalytics())}catch(e:any){setError(e?.message||"Failed to load analytics.")}finally{setLoading(false)}}
 const m=data?.metrics||{}, r=data?.revenue_by_service||{};
 return <AdminProtectedRoute><div className="min-h-screen bg-slate-50 flex"><AdminSidebar active="Admin Reports"/>
 <main className="flex-1 p-6 xl:p-8 min-w-0">
 <header className="flex justify-between gap-4"><div><p className="text-sm font-bold text-violet-700">Firmic Admin</p><h1 className="text-3xl font-bold mt-1">Admin Analytics</h1><p className="text-slate-500 mt-2">Live platform revenue, occupancy, and workforce intelligence.</p></div><button onClick={load} className="bg-violet-600 text-white px-6 py-3 rounded-xl font-bold h-fit">{loading?"Refreshing...":"Refresh"}</button></header>
 {error&&<div className="mt-6 bg-red-50 border border-red-200 text-red-700 rounded-2xl p-4">{error}</div>}
 <section className="grid grid-cols-1 md:grid-cols-4 gap-5 mt-8">
 <Stat icon="🏢" title="Tenant Companies" value={m.tenant_companies||0}/><Stat icon="🔒" title="Rented Offices" value={m.rented_offices||0}/><Stat icon="🤖" title="Active AI Agents" value={m.active_ai_agents||0}/><Stat icon="💰" title="Ledger Total" value={money(m.ledger_total)}/>
 </section>
 <section className="grid grid-cols-1 xl:grid-cols-2 gap-6 mt-8">
 <Panel title="Revenue Status"><Row label="Paid Revenue" value={money(m.paid_revenue)}/><Row label="Outstanding" value={money(m.outstanding)}/><Row label="Ledger Entries" value={data?.ledger_entries||0}/></Panel>
 <Panel title="Revenue by Service"><Row label="Office" value={money(r.office)}/><Row label="AI Workforce" value={money(r.ai_workforce)}/><Row label="Meeting Center" value={money(r.meeting_center)}/><Row label="Firmic Setup Fees" value={money(r.firmic_setup)}/></Panel>
 <Panel title="Platform Capacity"><Row label="Active Companies" value={m.active_companies||0}/><Row label="Available Offices" value={m.available_offices||0}/><Row label="Rented Offices" value={m.rented_offices||0}/></Panel>
 </section>
 </main></div></AdminProtectedRoute>
}
function Stat({icon,title,value}:any){return <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm"><div className="text-3xl">{icon}</div><p className="text-sm text-slate-500 mt-3">{title}</p><p className="text-2xl font-bold mt-1">{value}</p></div>}
function Panel({title,children}:any){return <section className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm"><h2 className="text-xl font-bold">{title}</h2><div className="mt-5">{children}</div></section>}
function Row({label,value}:any){return <div className="flex justify-between py-3 border-b border-slate-100"><span className="text-slate-500">{label}</span><strong>{value}</strong></div>}
function money(v:any){return `$${Number(v||0).toFixed(2)}`}
