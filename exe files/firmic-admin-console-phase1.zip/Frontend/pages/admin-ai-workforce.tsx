import { useEffect, useMemo, useState } from "react";
import AdminSidebar from "../components/AdminSidebar";
import AdminProtectedRoute from "../components/AdminProtectedRoute";
import { getAdminAIWorkforce } from "../services/adminApi";

export default function AdminAIWorkforce() {
  const [data, setData] = useState<any>(null);
  const [search, setSearch] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => { load(); }, []);

  async function load() {
    try {
      setLoading(true);
      setError("");
      setData(await getAdminAIWorkforce());
    } catch (err: any) {
      setError(err?.message || "Failed to load AI workforce.");
    } finally {
      setLoading(false);
    }
  }

  const agents = useMemo(() => {
    const rows = data?.agents || [];
    const query = search.trim().toLowerCase();
    if (!query) return rows;
    return rows.filter((agent: any) =>
      `${agent.agent_name} ${agent.company_name} ${agent.status} ${agent.headquarters || ""}`
        .toLowerCase().includes(query)
    );
  }, [data, search]);

  const metrics = data?.metrics || {};

  return (
    <AdminProtectedRoute>
      <div className="min-h-screen bg-slate-50 flex">
        <AdminSidebar active="AI Workforce Admin" />
        <main className="flex-1 p-6 xl:p-8 min-w-0">
          <Header title="AI Workforce Monitor"
            text="Live AI employees across every tenant company, directly from PostgreSQL."
            loading={loading} onRefresh={load} />
          {error && <ErrorBox text={error} />}

          <section className="grid grid-cols-1 md:grid-cols-5 gap-5 mt-8">
            <Stat icon="🤖" title="Total Agents" value={metrics.total_agents || 0} />
            <Stat icon="✅" title="Active" value={metrics.active_agents || 0} />
            <Stat icon="⏸️" title="Inactive" value={metrics.inactive_agents || 0} />
            <Stat icon="🏢" title="Companies Served" value={metrics.companies_with_agents || 0} />
            <Stat icon="💰" title="Monthly Cost" value={money(metrics.monthly_cost_usd)} />
          </section>

          <section className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm mt-8">
            <input className="w-full border border-slate-200 rounded-xl px-4 py-3"
              value={search} onChange={(e) => setSearch(e.target.value)}
              placeholder="Search agent, company, office, or status..." />
          </section>

          <section className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm mt-6">
            <h2 className="text-xl font-bold">Company AI Workforce</h2>
            <div className="space-y-3 mt-5">
              {loading ? <p className="text-slate-500">Loading agents...</p> :
               agents.length === 0 ? <p className="text-slate-500">No AI agents match this search.</p> :
               agents.map((agent: any) => (
                <div key={agent.id}
                  className="grid grid-cols-1 md:grid-cols-[1fr_1fr_140px_130px_120px] gap-4 items-center bg-slate-50 border border-slate-200 rounded-2xl p-4">
                  <Info title="AI Employee" value={agent.agent_name} />
                  <Info title="Tenant Company" value={agent.company_name} />
                  <Info title="Headquarters" value={agent.headquarters || "None"} />
                  <Info title="Monthly Price" value={money(agent.monthly_price_usd)} />
                  <Badge value={agent.status} />
                </div>
              ))}
            </div>
          </section>
        </main>
      </div>
    </AdminProtectedRoute>
  );
}
function Header({title,text,loading,onRefresh}:any){return <header className="flex flex-col lg:flex-row lg:items-center justify-between gap-4"><div><p className="text-sm font-bold text-violet-700">Firmic Admin</p><h1 className="text-3xl font-bold mt-1">{title}</h1><p className="text-slate-500 mt-2">{text}</p></div><button onClick={onRefresh} disabled={loading} className="bg-violet-600 text-white px-6 py-3 rounded-xl font-bold disabled:bg-slate-300">{loading?"Refreshing...":"Refresh"}</button></header>}
function Stat({icon,title,value}:any){return <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm"><div className="text-3xl">{icon}</div><p className="text-sm text-slate-500 mt-3">{title}</p><p className="text-2xl font-bold mt-1">{value}</p></div>}
function Info({title,value}:any){return <div><p className="text-xs text-slate-500">{title}</p><p className="font-bold mt-1">{value}</p></div>}
function Badge({value}:any){const active=String(value).toLowerCase()==="active";return <span className={`w-fit px-3 py-1 rounded-full text-xs font-bold ${active?"bg-green-100 text-green-700":"bg-slate-200 text-slate-600"}`}>{value}</span>}
function ErrorBox({text}:any){return <div className="mt-6 bg-red-50 border border-red-200 text-red-700 rounded-2xl p-4">{text}</div>}
function money(value:any){return `$${Number(value||0).toFixed(2)}`}
