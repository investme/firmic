import { useEffect, useState } from "react";
import AdminSidebar from "../components/AdminSidebar";
import AdminProtectedRoute from "../components/AdminProtectedRoute";
import { getAdminSettings } from "../services/adminApi";

export default function AdminSettings() {
  const [data,setData]=useState<any>(null);
  const [loading,setLoading]=useState(true);
  const [error,setError]=useState("");

  useEffect(()=>{load()},[]);
  async function load(){try{setLoading(true);setError("");setData(await getAdminSettings())}catch(e:any){setError(e?.message||"Failed to load settings.")}finally{setLoading(false)}}

  const platform=data?.platform||{};
  const pricing=data?.pricing||{};
  const inventory=data?.inventory||{};
  const billing=data?.billing||{};

  return <AdminProtectedRoute><div className="min-h-screen bg-slate-50 flex">
    <AdminSidebar active="Admin Settings"/>
    <main className="flex-1 p-6 xl:p-8 min-w-0">
      <header className="flex justify-between gap-4"><div>
        <p className="text-sm font-bold text-violet-700">Firmic Admin</p>
        <h1 className="text-3xl font-bold mt-1">Platform Settings</h1>
        <p className="text-slate-500 mt-2">Live MVP configuration and billing policy reference.</p>
      </div><button onClick={load} className="bg-violet-600 text-white px-6 py-3 rounded-xl font-bold h-fit">{loading?"Refreshing...":"Refresh"}</button></header>
      {error&&<div className="mt-6 bg-red-50 border border-red-200 text-red-700 rounded-2xl p-4">{error}</div>}

      <section className="grid grid-cols-1 md:grid-cols-4 gap-5 mt-8">
        <Stat title="Hookup Fee" value={money(pricing.hookup_fee_usd)} icon="🔌"/>
        <Stat title="VAT Rate" value={`${Number(platform.vat_rate||0)*100}%`} icon="🧾"/>
        <Stat title="Offices" value={inventory.total_offices||0} icon="🏢"/>
        <Stat title="AED Rate" value={platform.aed_conversion_rate||0} icon="💱"/>
      </section>

      <section className="grid grid-cols-1 xl:grid-cols-2 gap-6 mt-8">
        <Panel title="Platform">
          <Row label="Environment" value={platform.environment}/>
          <Row label="Database" value={platform.database}/>
          <Row label="Tenant Registration" value={yes(platform.tenant_registration_enabled)}/>
          <Row label="Tenant Isolation" value={yes(platform.tenant_isolation_enabled)}/>
          <Row label="Base Currency" value={platform.currency}/>
        </Panel>

        <Panel title="Pricing Policy">
          <Row label="One-Time Hookup Fee" value={money(pricing.hookup_fee_usd)}/>
          <Row label="Office Monthly Default" value={money(pricing.default_office_monthly_usd)}/>
          <Row label="Meeting Room / Hour" value={money(pricing.meeting_room_hourly_usd)}/>
          <Row label="Business Number / Month" value={money(pricing.business_number_monthly_usd)}/>
          <Row label="Digital Mailroom / Month" value={money(pricing.digital_mailroom_monthly_usd)}/>
          <Row label="Microsoft 365 / Month" value={money(pricing.microsoft_365_monthly_usd)}/>
        </Panel>

        <Panel title="Inventory">
          <Row label="Total Offices" value={inventory.total_offices}/>
          <Row label="Available" value={inventory.available_offices}/>
          <Row label="Rented" value={inventory.rented_offices}/>
          <Row label="Active Companies" value={inventory.active_companies}/>
        </Panel>

        <Panel title="Billing Engine">
          <Row label="Usage Ledger" value={yes(billing.ledger_enabled)}/>
          <Row label="Automatic Setup Fee Reconciliation" value={yes(billing.automatic_setup_fee_reconciliation)}/>
          <Row label="Setup Fee Tax" value={billing.tax_applied_to_setup_fee?"Applied":"Not applied"}/>
          <Row label="Statuses" value={(billing.supported_statuses||[]).join(", ")}/>
        </Panel>
      </section>

      <div className="mt-6 bg-violet-50 border border-violet-200 text-violet-800 rounded-2xl p-5">
        <p className="font-bold">MVP Settings Policy</p>
        <p className="text-sm mt-2">These values are live configuration references. Editable persistent settings can be added after the core synchronization phase without changing the current billing architecture.</p>
      </div>
    </main>
  </div></AdminProtectedRoute>
}
function Stat({title,value,icon}:any){return <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm"><div className="text-3xl">{icon}</div><p className="text-sm text-slate-500 mt-3">{title}</p><p className="text-2xl font-bold mt-1">{value}</p></div>}
function Panel({title,children}:any){return <section className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm"><h2 className="text-xl font-bold">{title}</h2><div className="mt-5">{children}</div></section>}
function Row({label,value}:any){return <div className="flex justify-between gap-5 py-3 border-b border-slate-100 last:border-0"><span className="text-slate-500">{label}</span><strong className="text-right">{String(value??"—")}</strong></div>}
function money(v:any){return `$${Number(v||0).toFixed(2)}`}
function yes(v:any){return v?"Enabled":"Disabled"}
