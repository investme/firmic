import { useEffect,useState } from "react";
import AdminSidebar from "../components/AdminSidebar";
import AdminProtectedRoute from "../components/AdminProtectedRoute";
import { getAdminSupport } from "../services/adminApi";

export default function AdminSupport(){
 const [data,setData]=useState<any>(null);const [error,setError]=useState("");const [loading,setLoading]=useState(true);
 useEffect(()=>{load()},[]);
 async function load(){try{setLoading(true);setError("");setData(await getAdminSupport())}catch(e:any){setError(e?.message||"Failed to load support center.")}finally{setLoading(false)}}
 const m=data?.metrics||{};
 return <AdminProtectedRoute><div className="min-h-screen bg-slate-50 flex"><AdminSidebar active="Support Inbox"/>
 <main className="flex-1 p-6 xl:p-8 min-w-0">
 <header className="flex justify-between gap-4"><div><p className="text-sm font-bold text-violet-700">Firmic Admin</p><h1 className="text-3xl font-bold mt-1">Support Center</h1><p className="text-slate-500 mt-2">Operational support queue with an honest empty state until tickets are persisted.</p></div><button onClick={load} className="bg-violet-600 text-white px-6 py-3 rounded-xl font-bold h-fit">{loading?"Refreshing...":"Refresh"}</button></header>
 {error&&<div className="mt-6 bg-red-50 border border-red-200 text-red-700 rounded-2xl p-4">{error}</div>}
 <section className="grid grid-cols-1 md:grid-cols-4 gap-5 mt-8"><Stat title="Open" value={m.open_tickets||0} icon="🔔"/><Stat title="Pending" value={m.pending_tickets||0} icon="⏳"/><Stat title="Resolved" value={m.resolved_tickets||0} icon="✅"/><Stat title="Tenant Companies" value={m.companies_available||0} icon="🏢"/></section>
 <section className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm mt-8"><h2 className="text-xl font-bold">Support Queue</h2>
 <div className="mt-5 bg-slate-50 border border-slate-200 rounded-2xl p-5"><p className="font-bold">No support tickets have been created.</p><p className="text-sm text-slate-500 mt-2">{data?.message}</p></div></section>
 <section className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm mt-6"><h2 className="text-xl font-bold">Available Tenant Context</h2><div className="space-y-3 mt-5">{(data?.companies||[]).map((c:any)=><div key={c.id} className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-slate-50 border border-slate-200 rounded-2xl p-4"><Info title="Company" value={c.name}/><Info title="Status" value={c.status}/><Info title="Headquarters" value={c.headquarters||"None"}/></div>)}</div></section>
 </main></div></AdminProtectedRoute>
}
function Stat({title,value,icon}:any){return <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm"><div className="text-3xl">{icon}</div><p className="text-sm text-slate-500 mt-3">{title}</p><p className="text-2xl font-bold mt-1">{value}</p></div>}
function Info({title,value}:any){return <div><p className="text-xs text-slate-500">{title}</p><p className="font-bold mt-1">{value}</p></div>}
