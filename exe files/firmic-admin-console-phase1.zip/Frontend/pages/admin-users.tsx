import { useEffect, useMemo, useState } from "react";
import AdminSidebar from "../components/AdminSidebar";
import AdminProtectedRoute from "../components/AdminProtectedRoute";
import { getAdminUsers } from "../services/adminApi";

export default function AdminUsers() {
  const [data, setData] = useState<any>(null);
  const [search, setSearch] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => { load(); }, []);

  async function load() {
    try {
      setLoading(true); setError("");
      setData(await getAdminUsers());
    } catch (err: any) {
      setError(err?.message || "Failed to load users.");
    } finally { setLoading(false); }
  }

  const users = useMemo(() => {
    const rows = data?.users || [];
    const q = search.trim().toLowerCase();
    if (!q) return rows;
    return rows.filter((u:any) =>
      `${u.full_name} ${u.email} ${u.role}`.toLowerCase().includes(q)
    );
  }, [data, search]);

  const m = data?.metrics || {};

  return <AdminProtectedRoute>
    <div className="min-h-screen bg-slate-50 flex">
      <AdminSidebar active="Admin Users & Roles" />
      <main className="flex-1 p-6 xl:p-8 min-w-0">
        <header className="flex justify-between gap-4">
          <div><p className="text-sm font-bold text-violet-700">Firmic Admin</p>
          <h1 className="text-3xl font-bold mt-1">Users & Roles</h1>
          <p className="text-slate-500 mt-2">Real authentication accounts and company ownership.</p></div>
          <button onClick={load} disabled={loading} className="bg-violet-600 text-white px-6 py-3 rounded-xl h-fit font-bold">{loading?"Refreshing...":"Refresh"}</button>
        </header>
        {error && <div className="mt-6 bg-red-50 border border-red-200 text-red-700 rounded-2xl p-4">{error}</div>}

        <section className="grid grid-cols-1 md:grid-cols-4 gap-5 mt-8">
          <Stat title="Total Users" value={m.total_users||0} icon="👥"/>
          <Stat title="Admins" value={m.admin_users||0} icon="🛡️"/>
          <Stat title="Tenant Owners" value={m.tenant_users||0} icon="🏢"/>
          <Stat title="With Companies" value={m.users_with_companies||0} icon="✅"/>
        </section>

        <section className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm mt-8">
          <input value={search} onChange={e=>setSearch(e.target.value)}
            placeholder="Search name, email, or role..."
            className="w-full border border-slate-200 rounded-xl px-4 py-3"/>
        </section>

        <section className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm mt-6">
          <h2 className="text-xl font-bold">Authentication Directory</h2>
          <div className="space-y-3 mt-5">
            {users.map((u:any)=><div key={u.id} className="grid grid-cols-1 md:grid-cols-[1fr_1fr_130px_130px_150px] gap-4 bg-slate-50 border border-slate-200 rounded-2xl p-4 items-center">
              <Info title="Name" value={u.full_name||"Unnamed User"}/>
              <Info title="Email" value={u.email}/>
              <Info title="Role" value={u.role}/>
              <Info title="Companies" value={u.companies_owned}/>
              <Info title="Created" value={date(u.created_at)}/>
            </div>)}
            {!loading && users.length===0 && <p className="text-slate-500">No users found.</p>}
          </div>
        </section>
      </main>
    </div>
  </AdminProtectedRoute>
}
function Stat({title,value,icon}:any){return <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm"><div className="text-3xl">{icon}</div><p className="text-sm text-slate-500 mt-3">{title}</p><p className="text-2xl font-bold mt-1">{value}</p></div>}
function Info({title,value}:any){return <div className="min-w-0"><p className="text-xs text-slate-500">{title}</p><p className="font-bold mt-1 break-words">{value}</p></div>}
function date(v:any){return v?new Date(v).toLocaleDateString():"—"}
