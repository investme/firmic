import { logout } from "../services/authApi";

const groups = [
  {
    title: "Overview",
    items: [
      ["Admin Command Center", "/admin", "🏛️"],
      ["All Companies", "/admin-companies", "🏢"],
      ["Office Inventory", "/admin-offices", "🗂️"],
    ],
  },
  {
    title: "Operations",
    items: [
      ["Tenant Billing", "/admin-billing", "💳"],
      ["Compliance Queue", "/admin-compliance", "🛡️"],
      ["Support Inbox", "/admin-support", "💬"],
      ["AI Workforce Admin", "/admin-ai-workforce", "🤖"],
    ],
  },
  {
    title: "Intelligence",
    items: [
      ["Admin Reports", "/admin-analytics", "📊"],
    ],
  },
  {
    title: "System",
    items: [
      ["Admin Users & Roles", "/admin-users", "👥"],
      ["Admin Settings", "/admin-settings", "⚙️"],
    ],
  },
];

export default function AdminSidebar({
  active,
}: {
  active: string;
}) {
  return (
    <aside className="hidden lg:flex w-72 h-screen sticky top-0 bg-slate-950 text-white flex-col shrink-0">
      <div className="p-5 border-b border-slate-900">
        <div className="flex items-center gap-3">
          <div className="h-11 w-11 rounded-2xl bg-gradient-to-br from-violet-600 to-fuchsia-500 flex items-center justify-center text-lg font-bold">
            ◆
          </div>

          <div>
            <p className="text-[10px] text-violet-400 font-bold uppercase tracking-widest">
              Firmic Internal
            </p>

            <h1 className="text-2xl font-bold">
              Admin Console
            </h1>

            <p className="text-xs text-slate-400">
              Platform Operations
            </p>
          </div>
        </div>
      </div>

      <div className="px-4 pt-4">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
          <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">
            Current Mode
          </p>

          <div className="flex justify-between items-center mt-3">
            <div>
              <p className="font-bold">
                Firmic Employee
              </p>

              <p className="text-xs text-green-400 mt-1">
                Admin access active
              </p>
            </div>

            <div className="h-10 w-10 rounded-xl bg-violet-600/20 flex items-center justify-center">
              🛡️
            </div>
          </div>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto px-4 py-4">
        {groups.map((group) => (
          <div
            key={group.title}
            className="mb-5"
          >
            <p className="px-4 mb-2 text-[10px] uppercase tracking-widest font-bold text-slate-500">
              {group.title}
            </p>

            <div className="space-y-1">
              {group.items.map(
                ([label, href, icon]) => (
                  <a
                    key={label}
                    href={href}
                    className={`flex items-center gap-3 px-4 py-3 rounded-2xl font-semibold transition ${
                      active === label
                        ? "bg-gradient-to-r from-violet-700 to-fuchsia-500 text-white"
                        : "text-slate-300 hover:bg-slate-900 hover:text-white"
                    }`}
                  >
                    <span className="w-6 text-center">
                      {icon}
                    </span>
                    <span>{label}</span>
                  </a>
                )
              )}
            </div>
          </div>
        ))}
      </nav>

      <div className="border-t border-slate-900 p-4">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
          <p className="text-sm font-bold">
            Controlled Admin Access
          </p>

          <p className="text-xs text-slate-400 mt-1 leading-5">
            Tenant workspaces open only through a selected company record.
          </p>
        </div>

        <button
          type="button"
          onClick={() =>
            logout("/admin-login")
          }
          className="mt-3 w-full bg-slate-900 hover:bg-red-600 text-white py-3 rounded-xl font-bold text-sm"
        >
          Logout
        </button>
      </div>
    </aside>
  );
}
