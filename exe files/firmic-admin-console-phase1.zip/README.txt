FIRMIC ADMIN CONSOLE PHASE 1

REPLACE:
Backend/routes/admin.py
Backend/routes/company.py
Frontend/services/adminApi.ts
Frontend/pages/admin-ai-workforce.tsx
Frontend/pages/admin-users.tsx
Frontend/pages/admin-settings.tsx
Frontend/pages/admin-analytics.tsx
Frontend/pages/admin-support.tsx
Frontend/pages/admin-billing.tsx

DO NOT replace AdminSidebar from the oddly named copied file in this ZIP.
Your uploaded current Frontend/components/AdminSidebar.tsx is already correct.

WHAT CHANGED:
- Admin Billing automatically reconciles missing lifetime $49 setup fees before loading.
- Existing paid/billed/unbilled setup fees are never duplicated.
- AI Workforce Admin reads CompanyAIAgent records.
- Users & Roles reads real User records and company ownership counts.
- Settings shows real MVP policy/configuration values.
- Analytics reads real ledger, office, company, and AI-agent totals.
- Support has its own honest zero-ticket state.

RESTART:
Backend: uvicorn main:app --reload
Frontend: npm run dev

VALIDATE:
1. Open Admin > Tenant Billing.
2. Soso should show 4 ledger entries and $230.65 total.
3. Tatok should include a $49 Firmic Setup entry.
4. Open AI Workforce Admin and confirm Soso Receptionist AI appears.
5. Open Users & Roles and confirm actual registered accounts appear.
6. Open Settings and confirm hookup fee = $49.
7. Open Admin Reports and confirm Firmic Setup Fees revenue is visible.
