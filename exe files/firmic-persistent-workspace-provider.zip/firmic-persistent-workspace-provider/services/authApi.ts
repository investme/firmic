import { API_URL } from "./config";
import { clearWorkspaceSnapshot } from "../src/utils/workspaceContext";

export type AuthRole = "tenant" | "admin";

export type AuthUser = {
  id: string | number;
  email: string;
  full_name?: string;
  role?: AuthRole | string;
};

export type AuthResponse = {
  access_token: string;
  token_type: string;
  user: AuthUser;
};

function isBrowser(): boolean {
  return typeof window !== "undefined";
}

export function saveAuthSession(data: AuthResponse) {
  if (!isBrowser()) return;
  localStorage.setItem("firmic_token", data.access_token);
  localStorage.setItem("firmic_user", JSON.stringify(data.user));
}

export function getAuthToken() {
  if (!isBrowser()) return null;
  return localStorage.getItem("firmic_token");
}

export function getAuthUser(): AuthUser | null {
  if (!isBrowser()) return null;
  const raw = localStorage.getItem("firmic_user");
  if (!raw) return null;

  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

export function getUserRole(): string | null {
  return getAuthUser()?.role || null;
}

export function isAdmin(): boolean {
  return getUserRole() === "admin";
}

export function isTenant(): boolean {
  const role = getUserRole();
  return role === "tenant" || role === "user" || !role;
}

// Keeps firmic_workspace_id, clears only the stale workspace snapshot.
export function logout(redirectTo = "/login") {
  if (!isBrowser()) return;

  localStorage.removeItem("firmic_token");
  localStorage.removeItem("firmic_user");
  clearWorkspaceSnapshot();
  window.location.href = redirectTo;
}

export async function registerUser(data: {
  email: string;
  full_name: string;
  password: string;
}) {
  const res = await fetch(`${API_URL}/api/auth/register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });

  const text = await res.text();
  if (!res.ok) throw new Error(text || "Failed to register");

  const result = text ? JSON.parse(text) : null;
  if (!result?.access_token || !result?.user) {
    throw new Error("Invalid registration response");
  }

  saveAuthSession(result);
  return result as AuthResponse;
}

export async function loginUser(data: {
  email: string;
  password: string;
}) {
  const res = await fetch(`${API_URL}/api/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });

  const text = await res.text();
  if (!res.ok) throw new Error(text || "Failed to login");

  const result = text ? JSON.parse(text) : null;
  if (!result?.access_token || !result?.user) {
    throw new Error("Invalid login response");
  }

  saveAuthSession(result);
  return result as AuthResponse;
}

export async function getMe() {
  const token = getAuthToken();
  if (!token) throw new Error("Not authenticated");

  const res = await fetch(`${API_URL}/api/auth/me`, {
    headers: { Authorization: `Bearer ${token}` },
  });

  if (!res.ok) throw new Error("Failed to load current user");
  return res.json();
}
