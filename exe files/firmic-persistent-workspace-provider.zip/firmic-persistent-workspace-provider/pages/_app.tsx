import "../styles/globals.css";
import type { AppProps } from "next/app";

import { WorkspaceProvider } from "../src/context/WorkspaceProvider";

export default function App({ Component, pageProps }: AppProps) {
  return (
    <WorkspaceProvider>
      <Component {...pageProps} />
    </WorkspaceProvider>
  );
}
