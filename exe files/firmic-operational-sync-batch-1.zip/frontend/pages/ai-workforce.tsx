import { useEffect, useMemo, useState } from "react";
import FirmicSidebar from "../components/FirmicSidebar";
import ProtectedRoute from "../components/ProtectedRoute";
import { aiAgents } from "../src/data/aiAgents";
import { toAED } from "../src/data/pricing";
import {
  getActiveWorkspace,
  getWorkspaceChangedEventName,
} from "../src/utils/workspaceContext";
import {
  deactivateAIAgent,
  getCompanyAIAgents,
  hireAIAgent,
} from "../services/aiWorkforceApi";

type ActiveAgent = {
  id: string;
  agent_name: string;
  monthly_price_usd: number;
  status: string;
};

export default function AIWorkforcePage() {
  const [workspace, setWorkspace] = useState(() =>
    getActiveWorkspace()
  );
  const [activeAgents, setActiveAgents] = useState<ActiveAgent[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyAgent, setBusyAgent] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  useEffect(() => {
    const sync = () => setWorkspace(getActiveWorkspace());
    sync();
    window.addEventListener(getWorkspaceChangedEventName(), sync);
    window.addEventListener("storage", sync);

    return () => {
      window.removeEventListener(getWorkspaceChangedEventName(), sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  useEffect(() => {
    loadAgents();
  }, [workspace?.id]);

  async function loadAgents() {
    if (!workspace?.id) {
      setActiveAgents([]);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError("");

      const data = await getCompanyAIAgents(workspace.id);
      setActiveAgents(Array.isArray(data) ? data : []);
    } catch (err: any) {
      setError(err?.message || "Failed to load AI workforce.");
    } finally {
      setLoading(false);
    }
  }

  async function toggleAgent(agent: any) {
    if (!workspace?.id) {
      setError("Select a company first.");
      return;
    }

    const isActive = activeAgents.some(
      (item) => item.agent_name === agent.name
    );

    try {
      setBusyAgent(agent.name);
      setError("");
      setNotice("");

      if (isActive) {
        await deactivateAIAgent({
          company_id: workspace.id,
          agent_name: agent.name,
        });
        setNotice(`${agent.name} deactivated.`);
      } else {
        await hireAIAgent({
          company_id: workspace.id,
          agent_name: agent.name,
          monthly_price_usd: agent.price,
        });
        setNotice(`${agent.name} hired successfully.`);
      }

      await loadAgents();
    } catch (err: any) {
      setError(err?.message || "AI workforce action failed.");
    } finally {
      setBusyAgent("");
    }
  }

  const selectedNames = activeAgents.map(
    (agent) => agent.agent_name
  );

  const monthlyUsd = useMemo(
    () =>
      activeAgents.reduce(
        (sum, agent) =>
          sum + Number(agent.monthly_price_usd || 0),
        0
      ),
    [activeAgents]
  );

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-slate-50 flex">
        <FirmicSidebar active="AI Workforce" />

        <main className="flex-1 p-6 xl:p-8">
          <header className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div>
              <p className="text-sm font-bold text-violet-700">
                AI Workforce
              </p>
              <h1 className="text-3xl font-bold mt-1">
                Hire the AI team for {workspace?.name || "Active Company"}.
              </h1>
              <p className="text-slate-500 mt-2">
                AI workforce state is now stored in PostgreSQL and shared with Admin and Billing.
              </p>
            </div>

            <div className="bg-white border border-slate-200 rounded-2xl px-5 py-3 shadow-sm">
              <p className="text-sm text-slate-500">
                Selected Workforce
              </p>
              <p className="font-bold">
                {activeAgents.length} Agents · ${monthlyUsd}/mo · AED {toAED(monthlyUsd)}/mo
              </p>
            </div>
          </header>

          {error && (
            <div className="mt-6 bg-red-50 border border-red-200 text-red-700 rounded-2xl p-4">
              {error}
            </div>
          )}

          {notice && (
            <div className="mt-6 bg-green-50 border border-green-200 text-green-700 rounded-2xl p-4">
              {notice}
            </div>
          )}

          <section className="grid grid-cols-1 md:grid-cols-4 gap-5 mt-6">
            <Stat title="Available AI Employees" value={String(aiAgents.length)} icon="🤖" />
            <Stat title="Active Workforce" value={String(activeAgents.length)} icon="✅" />
            <Stat title="Monthly USD" value={`$${monthlyUsd}`} icon="💰" />
            <Stat title="Monthly AED" value={`AED ${toAED(monthlyUsd)}`} icon="🇦🇪" />
          </section>

          {loading ? (
            <div className="mt-8 bg-white border border-slate-200 rounded-3xl p-6">
              Loading AI workforce...
            </div>
          ) : (
            <section className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5 mt-8">
              {aiAgents.map((agent, index) => {
                const active = selectedNames.includes(agent.name);
                const busy = busyAgent === agent.name;

                return (
                  <article
                    key={agent.name}
                    className={`bg-white rounded-3xl border p-6 shadow-sm ${
                      active
                        ? "border-violet-400"
                        : "border-slate-200"
                    }`}
                  >
                    <div className="flex justify-between">
                      <div className="h-14 w-14 rounded-2xl bg-violet-100 flex items-center justify-center text-2xl">
                        {index % 2 ? "👤" : "🤖"}
                      </div>

                      <span
                        className={`px-3 py-1 rounded-full text-xs font-bold ${
                          active
                            ? "bg-green-100 text-green-700"
                            : "bg-slate-100 text-slate-500"
                        }`}
                      >
                        {active ? "Active" : "Available"}
                      </span>
                    </div>

                    <h2 className="text-xl font-bold mt-5">
                      {agent.name}
                    </h2>

                    <p className="text-sm text-slate-500 mt-2 min-h-[52px]">
                      {agent.desc}
                    </p>

                    <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 mt-5">
                      <p className="text-sm text-slate-500">
                        Monthly Cost
                      </p>
                      <p className="font-bold">
                        {agent.price} USD/mo
                      </p>
                      <p className="font-bold text-slate-500">
                        {toAED(agent.price)} AED/mo
                      </p>
                    </div>

                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => toggleAgent(agent)}
                      className={`w-full mt-5 py-3 rounded-xl font-bold disabled:opacity-50 ${
                        active
                          ? "bg-red-50 text-red-600"
                          : "bg-violet-600 text-white"
                      }`}
                    >
                      {busy
                        ? "Updating..."
                        : active
                        ? "Deactivate"
                        : "Hire"}
                    </button>
                  </article>
                );
              })}
            </section>
          )}
        </main>
      </div>
    </ProtectedRoute>
  );
}

function Stat({
  title,
  value,
  icon,
}: {
  title: string;
  value: string;
  icon: string;
}) {
  return (
    <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm">
      <div className="text-3xl">{icon}</div>
      <p className="text-sm text-slate-500 mt-3">{title}</p>
      <p className="text-2xl font-bold mt-1">{value}</p>
    </div>
  );
}
