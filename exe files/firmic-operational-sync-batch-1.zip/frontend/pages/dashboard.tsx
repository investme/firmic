import { useEffect, useMemo, useState } from "react";
import FirmicSidebar from "../components/FirmicSidebar";
import ProtectedRoute from "../components/ProtectedRoute";
import { toAED } from "../src/data/pricing";
import {
  getActiveWorkspace,
  getWorkspaceChangedEventName,
} from "../src/utils/workspaceContext";
import { getCompanyAIAgents } from "../services/aiWorkforceApi";
import { getCompanyMeetingBookings } from "../services/meetingBookingApi";
import { getCompanyLedgerSummary } from "../services/ledgerApi";
import { getCompanyActivity } from "../services/activityApi";

type ActiveAgent = {
  id: string;
  agent_name: string;
  monthly_price_usd: number;
};

type Booking = {
  id: string;
  room_name: string;
  booking_date: string;
  booking_time: string;
  duration_hours: number;
  hourly_price_usd: number;
};

type LedgerSummary = {
  subtotal: number;
  tax: number;
  total: number;
  services: Array<{
    service: string;
    total: number;
    entries: number;
  }>;
};

type Activity = {
  id: string;
  event_type: string;
  title: string;
  description?: string;
  created_at?: string;
};

export default function Dashboard() {
  const [workspace, setWorkspace] = useState(() =>
    getActiveWorkspace()
  );
  const [agents, setAgents] = useState<ActiveAgent[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [summary, setSummary] = useState<LedgerSummary | null>(null);
  const [activity, setActivity] = useState<Activity[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const sync = () => setWorkspace(getActiveWorkspace());

    sync();
    window.addEventListener(getWorkspaceChangedEventName(), sync);
    window.addEventListener("storage", sync);

    return () => {
      window.removeEventListener(getWorkspaceChangedEventName(), sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  useEffect(() => {
    loadDashboard();
  }, [workspace?.id]);

  async function loadDashboard() {
    if (!workspace?.id) {
      setAgents([]);
      setBookings([]);
      setSummary(null);
      setActivity([]);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError("");

      const results = await Promise.allSettled([
        getCompanyAIAgents(workspace.id),
        getCompanyMeetingBookings(workspace.id),
        getCompanyLedgerSummary(workspace.id),
        getCompanyActivity(workspace.id),
      ]);

      setAgents(
        results[0].status === "fulfilled" &&
          Array.isArray(results[0].value)
          ? results[0].value
          : []
      );

      setBookings(
        results[1].status === "fulfilled" &&
          Array.isArray(results[1].value)
          ? results[1].value
          : []
      );

      setSummary(
        results[2].status === "fulfilled"
          ? results[2].value
          : null
      );

      setActivity(
        results[3].status === "fulfilled" &&
          Array.isArray(results[3].value)
          ? results[3].value
          : []
      );

      if (
        results.some(
          (result) => result.status === "rejected"
        )
      ) {
        setError(
          "Some workspace modules could not be loaded. Available data is still shown."
        );
      }
    } finally {
      setLoading(false);
    }
  }

  const headquarters = workspace?.headquarters;
  const hasOffice = Boolean(headquarters?.office_code);
  const companyName = workspace?.name || "Active Company";
  const officeCode =
    headquarters?.office_code || "Not Selected";
  const officeLocation =
    headquarters?.location || "No headquarters selected";
  const businessNumber =
    headquarters?.phone || "Not Assigned";
  const officePrice =
    headquarters?.monthly_price_usd || 0;
  const plan = workspace?.plan || "Premium";

  const totalBookedHours = useMemo(
    () =>
      bookings.reduce(
        (sum, booking) =>
          sum + Number(booking.duration_hours || 0),
        0
      ),
    [bookings]
  );

  const monthlyTotal = Number(summary?.total || 0);
  const subtotal = Number(summary?.subtotal || 0);
  const tax = Number(summary?.tax || 0);
  const activeServices = summary?.services?.length || 0;
  const hookupFee = monthlyTotal > 0 ? 49 : 0;
  const checkout = monthlyTotal + hookupFee;

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-slate-50 flex">
        <FirmicSidebar active="Command Center" />

        <main className="flex-1 p-6 xl:p-8">
          <header className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div>
              <p className="text-sm font-bold text-violet-700">
                Command Center
              </p>

              <h1 className="text-3xl font-bold text-slate-950 mt-1">
                {companyName}
              </h1>

              <p className="text-slate-500 mt-2 max-w-4xl">
                Headquarters, workforce, bookings, activity, and billing now come from the shared PostgreSQL platform.
              </p>
            </div>

            <div className="flex gap-3">
              <button
                type="button"
                onClick={loadDashboard}
                disabled={loading}
                className="border border-slate-200 bg-white px-5 py-3 rounded-xl font-bold disabled:opacity-50"
              >
                Refresh
              </button>

              <a
                href={hasOffice ? "/my-office" : "/virtual-offices"}
                className="bg-violet-600 text-white px-6 py-3 rounded-xl font-bold text-center"
              >
                {hasOffice
                  ? "Manage Headquarters"
                  : "Activate Headquarters"}
              </a>
            </div>
          </header>

          {error && (
            <div className="mt-6 bg-yellow-50 border border-yellow-200 text-yellow-700 rounded-2xl p-4">
              {error}
            </div>
          )}

          <section className="grid grid-cols-1 md:grid-cols-4 gap-5 mt-8">
            <Stat title="Headquarters" value={hasOffice ? officeCode : "None"} icon="🏢" />
            <Stat title="AI Workforce" value={String(agents.length)} icon="🤖" />
            <Stat title="Meeting Bookings" value={String(bookings.length)} icon="📅" />
            <Stat title="Current Billing" value={`$${monthlyTotal.toFixed(2)}`} icon="💰" />
          </section>

          <div className="grid grid-cols-1 xl:grid-cols-[1fr_380px] gap-6 mt-8">
            <div className="space-y-6">
              <section className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm">
                <div className="flex justify-between items-start gap-4">
                  <div>
                    <h2 className="text-xl font-bold">
                      Head Office
                    </h2>

                    <p className="text-sm text-slate-500 mt-1">
                      Registered company headquarters.
                    </p>
                  </div>

                  <a
                    href={hasOffice ? "/my-office" : "/virtual-offices"}
                    className="border border-slate-200 px-4 py-2 rounded-xl font-semibold"
                  >
                    {hasOffice ? "Manage Office" : "Rent Office"}
                  </a>
                </div>

                {!hasOffice ? (
                  <div className="mt-5 bg-slate-50 border border-slate-200 rounded-2xl p-6 text-slate-500">
                    No Headquarters has been assigned to this company.
                  </div>
                ) : (
                  <div className="mt-5 grid grid-cols-1 md:grid-cols-4 gap-4">
                    <Mini title="Office" value={officeCode} />
                    <Mini title="Location" value={officeLocation} />
                    <Mini title="Business Number" value={businessNumber} />
                    <Mini title="Plan" value={`${plan} · $${officePrice}/mo`} />
                  </div>
                )}
              </section>

              <section className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm">
                <div className="flex justify-between gap-4">
                  <div>
                    <h2 className="text-xl font-bold">
                      AI Workforce
                    </h2>

                    <p className="text-sm text-slate-500 mt-1">
                      PostgreSQL-backed company workforce.
                    </p>
                  </div>

                  <a
                    href="/ai-workforce"
                    className="text-violet-700 font-bold"
                  >
                    Manage →
                  </a>
                </div>

                {agents.length === 0 ? (
                  <p className="mt-5 text-slate-500">
                    No optional AI agents have been hired.
                  </p>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-5">
                    {agents.map((agent) => (
                      <div
                        key={agent.id}
                        className="bg-slate-50 border border-slate-200 rounded-2xl p-4"
                      >
                        <p className="font-bold">
                          {agent.agent_name}
                        </p>

                        <p className="text-sm text-green-600 mt-1">
                          Active
                        </p>

                        <p className="text-sm text-slate-500 mt-2">
                          ${agent.monthly_price_usd}/month
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </section>

              <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Panel title="Meeting Center">
                  <div className="grid grid-cols-2 gap-3">
                    <Mini title="Bookings" value={String(bookings.length)} />
                    <Mini title="Booked Hours" value={String(totalBookedHours)} />
                  </div>

                  <a
                    href="/meeting-rooms"
                    className="mt-4 block text-center bg-violet-600 text-white py-3 rounded-xl font-bold"
                  >
                    Manage Meetings
                  </a>
                </Panel>

                <Panel title="Activity Feed">
                  {activity.length === 0 ? (
                    <p className="text-slate-500">
                      No synchronized activity yet.
                    </p>
                  ) : (
                    <div className="space-y-3">
                      {activity.slice(0, 6).map((event) => (
                        <div
                          key={event.id}
                          className="border-b border-slate-100 pb-3"
                        >
                          <p className="font-semibold">
                            {event.title}
                          </p>

                          {event.description && (
                            <p className="text-sm text-slate-500 mt-1">
                              {event.description}
                            </p>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </Panel>
              </section>
            </div>

            <div className="space-y-6">
              <section className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm">
                <h2 className="text-xl font-bold">
                  Business Infrastructure Cost
                </h2>

                <div className="space-y-3 mt-5">
                  <Row title="Subtotal" value={`$${subtotal.toFixed(2)}`} />
                  <Row title="Tax" value={`$${tax.toFixed(2)}`} />
                  <Row title="Active Services" value={String(activeServices)} />
                  <Row title="One-Time Hookup" value={`$${hookupFee.toFixed(2)}`} />
                </div>

                <div className="mt-5 bg-violet-50 border border-violet-100 rounded-2xl p-4">
                  <p className="text-sm text-violet-700 font-bold">
                    Today’s Checkout
                  </p>

                  <h3 className="text-3xl font-bold text-violet-900 mt-1">
                    ${checkout.toFixed(2)}
                  </h3>

                  <p className="text-violet-700">
                    AED {toAED(checkout)}
                  </p>
                </div>

                <a
                  href="/billing"
                  className="mt-5 block text-center bg-violet-600 text-white py-3 rounded-xl font-bold"
                >
                  Open Billing Center
                </a>
              </section>

              <Panel title="Quick Actions">
                <Action href="/ai-workforce" text="Hire AI Employee" />
                <Action href="/meeting-rooms" text="Book Meeting Room" />
                <Action href="/my-office" text="Manage Headquarters" />
                <Action href="/billing" text="Review Billing" />
              </Panel>
            </div>
          </div>
        </main>
      </div>
    </ProtectedRoute>
  );
}

function Stat({ title, value, icon }: any) {
  return (
    <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm">
      <div className="text-3xl">{icon}</div>
      <p className="text-sm text-slate-500 mt-3">{title}</p>
      <p className="text-2xl font-bold mt-1">{value}</p>
    </div>
  );
}

function Panel({ title, children }: any) {
  return (
    <section className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm">
      <h2 className="text-xl font-bold">{title}</h2>
      <div className="mt-5">{children}</div>
    </section>
  );
}

function Mini({ title, value }: any) {
  return (
    <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 min-w-0">
      <p className="text-xs text-slate-500">{title}</p>
      <p className="font-bold mt-1 break-words">{value}</p>
    </div>
  );
}

function Row({ title, value }: any) {
  return (
    <div className="flex justify-between gap-4 py-3 border-b border-slate-100">
      <span className="text-slate-500">{title}</span>
      <span className="font-bold">{value}</span>
    </div>
  );
}

function Action({ href, text }: any) {
  return (
    <a
      href={href}
      className="flex justify-between items-center py-3 border-b border-slate-100 font-semibold hover:text-violet-700"
    >
      <span>{text}</span>
      <span>→</span>
    </a>
  );
}
