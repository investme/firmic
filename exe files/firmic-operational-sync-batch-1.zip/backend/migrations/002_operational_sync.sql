BEGIN;

CREATE TABLE IF NOT EXISTS company_ai_agents (
    id VARCHAR PRIMARY KEY,
    company_id VARCHAR NOT NULL,
    agent_name VARCHAR NOT NULL,
    monthly_price_usd DOUBLE PRECISION NOT NULL DEFAULT 0,
    status VARCHAR NOT NULL DEFAULT 'active',
    activated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deactivated_at TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_company_ai_agent UNIQUE (company_id, agent_name)
);

CREATE INDEX IF NOT EXISTS ix_company_ai_agents_company_id
ON company_ai_agents (company_id);

CREATE INDEX IF NOT EXISTS ix_company_ai_agents_status
ON company_ai_agents (status);

CREATE TABLE IF NOT EXISTS meeting_bookings (
    id VARCHAR PRIMARY KEY,
    company_id VARCHAR NOT NULL,
    room_id INTEGER NOT NULL,
    room_name VARCHAR NOT NULL,
    booking_date VARCHAR NOT NULL,
    booking_time VARCHAR NOT NULL,
    duration_hours INTEGER NOT NULL DEFAULT 1,
    hourly_price_usd DOUBLE PRECISION NOT NULL DEFAULT 25,
    status VARCHAR NOT NULL DEFAULT 'confirmed',
    ledger_entry_id VARCHAR,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    cancelled_at TIMESTAMP
);

CREATE INDEX IF NOT EXISTS ix_meeting_bookings_company_id
ON meeting_bookings (company_id);

CREATE INDEX IF NOT EXISTS ix_meeting_bookings_status
ON meeting_bookings (status);

CREATE INDEX IF NOT EXISTS ix_meeting_bookings_booking_date
ON meeting_bookings (booking_date);

COMMIT;
