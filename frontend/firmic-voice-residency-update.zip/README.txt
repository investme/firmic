FIRMIC VOICE + RESIDENCY UPDATE

Copy:
- pages/launch.tsx
- pages/documents.tsx

Changes:
1. Sonny and Hermes now use browser speech synthesis for their first encounters.
2. Voice can be turned on/off and replayed.
3. Browsers may block automatic speech until the user clicks once; the Replay Voice button always remains available.
4. Documents now asks whether the founder/authorized representative is a UAE resident.
5. Emirates ID is required only for UAE residents.
6. For non-residents, Emirates ID is marked Not Applicable and does not block compliance.
7. Passport and Proof of Address remain mandatory for everyone.

Run:
npm run build
