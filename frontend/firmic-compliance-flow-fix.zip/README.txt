FIRMIC COMPLIANCE FLOW FIX

Copy:
- pages/documents.tsx
- pages/launch.tsx

Fixes:
1. Selecting a compliance file uploads it immediately.
2. Successful uploads persist locally so Submit Compliance Package unlocks reliably.
3. Speak with Hermes opens inside the compliance portal.
4. Hermes speaks the verification status and explains the expected response is within 24 hours.
5. Submitting sets the Launch Engine to under_review and returns to /launch.
6. Company access remains locked during review.

Run:
npm run build
